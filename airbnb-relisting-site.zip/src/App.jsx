import React from 'react';
import HomeownerRelistingLanding from './HomeownerRelistingLanding';

export default function App() {
  return <HomeownerRelistingLanding />;
}
